package ilazar.postit.testdb;

import ilazar.postit.dao.NoteDAO;
import ilazar.postit.dao.NoteDAOImpl;
import ilazar.postit.entity.Note;
import ilazar.postit.service.NoteService;
import ilazar.postit.service.NoteServiceImpl;

public class TestApp {
	
	public static void main(String[] args) {
		
		
		
	}
}
